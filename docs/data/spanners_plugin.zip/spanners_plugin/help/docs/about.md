# About Us

We are a group of computer science students at [Osnabrück University](https://www.uni-osnabrueck.de/en/home/) who developed this plugin as part of a master's course. The contributors are:

- Dennis Benz
- Timo Glane
- Tim Hartmann
- Benedikte Lechtermann
- Steffen Meinert
- Levin Nemesch
- Leon Nienhüser
- Leon Richardt
- Jo Sandor
- Joshua Sangmeister
- Maria Stjepic
- Julian Pascal Wittker
